package com.example.pontuacao

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
